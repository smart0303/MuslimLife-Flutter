import 'package:flutter/cupertino.dart';

class NotificationProvider extends ChangeNotifier{

}